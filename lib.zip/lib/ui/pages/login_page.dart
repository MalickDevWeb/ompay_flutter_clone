// Importer les packages nécessaires pour l'interface Flutter et les opérations asynchrones
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:test_flutter/ui/pages/client_page.dart';
import 'package:test_flutter/ui/widgets/grid_background.dart';

// Widget principal de la page de connexion, stateful pour gérer le contenu dynamique
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});


  @override
  State<LoginPage> createState() => _LoginPageState();
}

// Classe d'état pour LoginPage, gère l'état et le cycle de vie
class _LoginPageState extends State<LoginPage> {
  // Contrôleur pour le carrousel d'images
  final PageController _pageController = PageController();
  // Contrôleur pour la saisie du numéro de téléphone
  final TextEditingController _phoneController = TextEditingController();
  // Contrôleur pour la saisie du code de vérification
  final TextEditingController _codeController = TextEditingController();
  // Timer pour avancer automatiquement le carrousel
  Timer? _timer;
  // Index de la page actuelle pour le clipach
  int _currentPage = 0;
  // Code pays sélectionné pour la saisie du téléphone
  String selectedCountryCode = '+221';
  // Étape actuelle : false pour téléphone, true pour code
  bool _isCodeStep = false;
  // Code attendu pour la vérification
  String? expectedCode;

  // Initialiser l'état, démarrer le timer du carrousel
  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (Timer timer) {
      if (_currentPage < 2) {
        _pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeIn,
        );
      } else {
        _timer?.cancel();
      }
    });
  }

  // Nettoyer les ressources lorsque le widget est supprimé
  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    _phoneController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  // Construire l'interface utilisateur pour la page de connexion
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      // Corps principal avec disposition verticale
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            child: CustomPaint(
              painter: GridPainter(),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Section supérieure avec carrousel d'images et transition ondulée
              Container(
                width: double.infinity,
                height: 290,
                color: const Color(0xFF0A0A0A),
                child: Stack(
                  children: [
                    // Fond bleu pour le PageView
                    Container(color: const Color(0xFF0A0A0A)),
                    SizedBox.expand(
                      child: PageView(
                        controller: _pageController,
                        onPageChanged: (int page) {
                          setState(() {
                            _currentPage = page;
                          });
                        },
                        children: [
                          Image.network(
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy-2mKzunreZ3bHZUciD4cuqmyj7s7jHVSMA&s',
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: double.infinity,
                          ),
                          Image.network(
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSg1OjstnvrXRwwqk3d1Z6MVlyHxFHvKlmtmQ&s',
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: double.infinity,
                          ),
                          Image.network(
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSg1OjstnvrXRwwqk3d1Z6MVlyHxFHvKlmtmQ&s',
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: double.infinity,
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      left: 0,
                      right: 0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          3,
                          (index) => Container(
                            width: 10,
                            height: 10,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _currentPage == index
                                  ? const Color(0xFFFF7900) // Actif : orange
                                  : Colors.grey, // Inactif : gris
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Barre grise centrale
              ClipPath(
                clipper: WavyClipper(),
                child: Container(
                  width: double.infinity,
                  height: 80,
                  color: const Color(0xFF1C1C1C), // Gris anthracite
                ),
              ),
              // Conteneur inférieur avec formulaire de connexion
              Expanded(
                child: Container(
                  height: 700,
                  width: double.infinity,
                  color: const Color(0xFF1C1C1C), // Gris anthracite
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Bienvenue sur OM Pay!',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _isCodeStep
                            ? 'Entrez le code de vérification de 6 chiffres'
                            : 'Entrez votre numéro mobile pour vous connecter',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 20),
                      _isCodeStep
                          ? TextField(
                              controller: _codeController,
                              maxLength: 6,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 24,
                                letterSpacing: 8,
                              ),
                              decoration: const InputDecoration(
                                hintText: '000000',
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                counterText: '',
                              ),
                            )
                          : Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.grey,
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: Colors.grey),
                                  ),
                                  child: DropdownButton<String>(
                                    value: selectedCountryCode,
                                    items: const [
                                      DropdownMenuItem(
                                        value: '+221',
                                        child: Text('🇸🇳 +221'),
                                      ),
                                      // Add more if needed
                                    ],
                                    onChanged: (value) {
                                      setState(() {
                                        selectedCountryCode = value!;
                                      });
                                    },
                                    underline: const SizedBox(),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: TextField(
                                    controller: _phoneController,
                                    decoration: const InputDecoration(
                                      hintText: 'Numéro de téléphone',
                                      fillColor: Colors.white,
                                      filled: true,
                                      border: OutlineInputBorder(),
                                    ),
                                    keyboardType: TextInputType.phone,
                                  ),
                                ),
                              ],
                            ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          if (_isCodeStep) {
                            if (_codeController.text == expectedCode) {
                              // Navigate to client page for specific phone
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const ClientPage(),
                                ),
                              );
                            }
                          } else {
                            // Check phone number
                            if (_phoneController.text == '771719013') {
                              expectedCode = '123456'; // Code spécifique
                            } else {
                              expectedCode = '000000'; // Code par défaut pour autres
                            }
                            // Switch to code step
                            setState(() {
                              _isCodeStep = true;
                            });
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFF7900),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 50,
                            vertical: 15,
                          ),
                        ),
                        child: Text(
                          _isCodeStep ? 'Vérifier' : 'Se connecter',
                          style: const TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        '© Orange Money tous les droits réservés by Teuw',
                        style: TextStyle(color: Colors.white, fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class WavyClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(0, 40);

    path.quadraticBezierTo(size.width * 0.25, 0, size.width * 0.5, 40);

    path.quadraticBezierTo(size.width * 0.75, 80, size.width, 40);

    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(oldClipper) => false;
}
