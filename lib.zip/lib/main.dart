import 'package:flutter/material.dart';
import 'package:test_flutter/ui/pages/login_page.dart';

void main() {
  runApp(
    MaterialApp(
      theme: ThemeData(
        scaffoldBackgroundColor: const Color.fromARGB(255, 73, 69, 69),
      ),
      home: const LoginPage(),
    ),
  );
}
